<?php
$host = "localhost";
$database_name = "violette_db";
$database_user = "root";
$database_password = "";
$port_number = "3306";
?>