
var Facture = {};

Facture.commande = function(id) {
	this.id = id;
}